import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import AppStack from './routes/homeStack';

export default function App() {
  return (
<AppStack/>
  )
}



